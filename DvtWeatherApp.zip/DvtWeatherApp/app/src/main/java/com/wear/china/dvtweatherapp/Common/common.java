package com.wear.china.dvtweatherapp.Common;

import android.support.annotation.NonNull;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Neo on 2017-11-07.
 */

public class common {
    public static String apiKey = "b8939f8dca3bc9dfa8e35a797aa15a6d";
    public static String apiLink = "http://api.openweathermap.org/data/2.5/weather";

    @NonNull
    public static String apiRequest(String lattitude, String longitute){
        StringBuilder sb = new StringBuilder(apiLink);

       // http://api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + lon + "&units=metric&appid=f4f0a01dd170f927829865108b4b396d
        sb.append(String.format("?lat=%s&lon=%s&lon=%s&units=metric&appid=%s", lattitude, longitute, apiKey));
        return  sb.toString();
    }

    public  static String TimeStamp(double timeStamp){
        DateFormat dateFormat = new SimpleDateFormat("HH:mm");
        Date date = new Date();
        date.setTime((long) timeStamp*1000);
        return  dateFormat.format(date);
    }

    public static  String getImage(String Icon){
        return String.format("http://openweathermap.org/img/w/%s.png", Icon);

    }

    public static String getDateNow(){
        DateFormat dateFormat = new SimpleDateFormat("dd MMMMM yyyy HH:mm");
        Date date = new Date();
        return dateFormat.format(date);
    }

}

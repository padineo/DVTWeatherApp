package com.wear.china.dvtweatherapp.Model;

/**
 * Created by Neo on 2017-11-08.
 */

public class Rain {
}

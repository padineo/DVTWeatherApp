package com.wear.china.dvtweatherapp.Model;

/**
 * Created by Neo on 2017-11-08.
 */

public class Clouds {
    private int all;

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }

    public Clouds(int all) {
        this.all = all;
    }
}

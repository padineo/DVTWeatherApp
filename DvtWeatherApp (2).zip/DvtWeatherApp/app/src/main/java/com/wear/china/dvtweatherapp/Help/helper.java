package com.wear.china.dvtweatherapp.Help;

import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Neo on 2017-11-08.
 */

public class helper {
    static String stream = null;

    public helper() {
    }

    public String getHTTPData(String urlString){
        try {
            URL url = new URL(urlString);
            HttpURLConnection httpConnect = (HttpURLConnection)url.openConnection();
            if (httpConnect.getResponseCode() == 200){
                BufferedReader r = new BufferedReader(new InputStreamReader(httpConnect.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null){
                    sb.append(line);
                    stream= sb.toString();
                    httpConnect.disconnect();
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();

        }
        return stream;
    }
}
